var Main = React.createClass({
  render() {
    return (
      <div>
        <Header />
        <Body />
      </div>
    )
  }
});
