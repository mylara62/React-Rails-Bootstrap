var Header = React.createClass({
  render() {
    return(
      <div>
        <h1>Create</h1>
      </div>
    )
  }
});
